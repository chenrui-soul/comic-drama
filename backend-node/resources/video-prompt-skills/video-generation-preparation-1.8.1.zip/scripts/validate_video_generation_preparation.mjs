import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const inputPath = process.argv[2];
const outputPath = process.argv[3];
const defaultCasesPath = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../examples/audio_routing_cases.json');
const casesPath = process.argv[4] ?? defaultCasesPath;

if (!inputPath) {
  console.error('Usage: node scripts/validate_video_generation_preparation.mjs <input.json> [output.json] [audio-routing-cases.json]');
  process.exit(2);
}

const fail = (message) => {
  console.error(`FAIL: ${message}`);
  process.exit(1);
};

const readJson = (filePath, label) => {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (error) {
    fail(`${label} is invalid JSON: ${error.message}`);
  }
};

const validateShape = (value, schema, rootSchema, location = '$') => {
  if (schema.$ref) {
    const prefix = '#/$defs/';
    if (!schema.$ref.startsWith(prefix)) fail(`${location} uses unsupported schema reference ${schema.$ref}`);
    return validateShape(value, rootSchema.$defs?.[schema.$ref.slice(prefix.length)], rootSchema, location);
  }
  if (Object.hasOwn(schema, 'const') && value !== schema.const) fail(`${location} must equal ${JSON.stringify(schema.const)}`);
  if (schema.enum && !schema.enum.includes(value)) fail(`${location} is not one of the allowed values`);
  if (schema.type) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    const actual = value === null ? 'null' : Array.isArray(value) ? 'array' : Number.isInteger(value) ? 'integer' : typeof value === 'object' ? 'object' : typeof value;
    const compatible = types.includes(actual) || (actual === 'integer' && types.includes('number'));
    if (!compatible) fail(`${location} expected ${types.join('|')}, got ${actual}`);
  }
  if (typeof value === 'string') {
    if (schema.minLength !== undefined && value.length < schema.minLength) fail(`${location} is too short`);
    if (schema.pattern && !new RegExp(schema.pattern).test(value)) fail(`${location} does not match ${schema.pattern}`);
    if (schema.format === 'date-time' && Number.isNaN(new Date(value).valueOf())) fail(`${location} is not a valid date-time`);
  }
  if (typeof value === 'number') {
    if (schema.minimum !== undefined && value < schema.minimum) fail(`${location} is below minimum`);
    if (schema.exclusiveMinimum !== undefined && value <= schema.exclusiveMinimum) fail(`${location} is below exclusive minimum`);
    if (schema.maximum !== undefined && value > schema.maximum) fail(`${location} exceeds maximum`);
  }
  if (Array.isArray(value)) {
    if (schema.minItems !== undefined && value.length < schema.minItems) fail(`${location} has too few items`);
    if (schema.uniqueItems && new Set(value.map((item) => JSON.stringify(item))).size !== value.length) fail(`${location} must contain unique items`);
    if (schema.items) value.forEach((item, index) => validateShape(item, schema.items, rootSchema, `${location}[${index}]`));
  }
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    for (const key of schema.required ?? []) if (!Object.hasOwn(value, key)) fail(`${location} is missing required property ${key}`);
    if (schema.additionalProperties === false) {
      for (const key of Object.keys(value)) if (!Object.hasOwn(schema.properties ?? {}, key)) fail(`${location} contains unexpected property ${key}`);
    }
    for (const [key, propertySchema] of Object.entries(schema.properties ?? {})) {
      if (Object.hasOwn(value, key)) validateShape(value[key], propertySchema, rootSchema, `${location}.${key}`);
    }
  }
};

const approxEqual = (left, right) => Math.abs(left - right) < 0.000001;
const assetKey = (assetId, version) => `${assetId}:${version}`;
const validateBindingInstruction = (instruction, label) => {
  if (typeof instruction !== 'string' || instruction.trim().length === 0) fail(`${label} binding_instruction is required`);
  if (instruction.length > 160) fail(`${label} binding_instruction exceeds 160 characters`);
  if (/\r|\n/.test(instruction)) fail(`${label} binding_instruction must be one short sentence without line breaks`);
};

// Project-fixed defaults. Model capability reasoning is intentionally disabled;
// the user selects the model upstream and confirms the final Prompt/assets.
const PROJECT_DEFAULT_CAPABILITIES = {
  input_modalities: {
    image: {supported: true, max_items: 9, max_duration_seconds: 0, mime_types: []},
    video: {supported: true, max_items: 3, max_duration_seconds: 0, mime_types: []},
    audio: {supported: true, max_items: 3, max_duration_seconds: 0, mime_types: []}
  },
  audio_capabilities: {
    audio_generation: {enabled: true, synchronized: true, dialogue: true, ambience: true, sfx: true, music: false, dialogue_suppressible: true},
    voice_conditioning: {supported: true, methods: ['reference_audio'], max_voice_references: 3, multi_speaker: true},
    dialogue_audio_drive: {supported: true, drives_lip_sync: true, max_items: 3, max_duration_seconds: 30, mime_types: []},
    lip_sync: {supported: true, source_modes: ['native_generated_dialogue', 'dialogue_audio_drive']}
  }
};

export const deriveAudioStrategy = (audioCapabilities, speakerCount, dialogueCueCount) => {
  return 'MODEL_NATIVE_VOICE';
};

const payload = readJson(inputPath, 'input');
const skillRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const inputSchema = readJson(path.join(skillRoot, 'schemas/video_generation_preparation_input.schema.json'), 'input schema');
validateShape(payload, inputSchema, inputSchema);
const required = [
  'project_id', 'generation_requested_at', 'upstream_contracts', 'storyboard_package',
  'production_segment', 'shots', 'storyboard_segment', 'approved_assets',
  'model_selection', 'selected_model_profile', 'production_parameters',
  'visual_context', 'sound_context', 'media_references'
];
const missing = required.filter((key) => !(key in payload));
if (missing.length) fail(`missing top-level fields: ${missing.join(', ')}`);
if (payload.upstream_contracts.visual_asset_voice_handoff !== '1.0') fail('Visual Asset voice handoff contract must be 1.0');
if (payload.upstream_contracts.storyboard_director_output !== '1.5') fail('Storyboard Director output contract must be 1.5');

const requestedAt = new Date(payload.generation_requested_at);
if (Number.isNaN(requestedAt.valueOf())) fail('generation_requested_at must be a valid date-time');

const source = payload.storyboard_package;
if (source.approval_status !== 'APPROVED') fail('storyboard_package must be APPROVED');
if (source.source_state !== 'STORYBOARD_REVIEW') fail('storyboard_package must come from STORYBOARD_REVIEW');

const {
  production_segment: segment,
  storyboard_segment: board,
  model_selection: selection,
  selected_model_profile: profile,
  production_parameters: params
} = payload;
if (segment.segment_id !== board.segment_id) fail('production_segment and storyboard_segment must have the same segment_id');
if (board.approval_status !== 'APPROVED') fail('storyboard_segment must be APPROVED');
if (segment.video_aspect_ratio !== params.aspect_ratio) fail('segment aspect ratio must match production_parameters.aspect_ratio');
if (!approxEqual(segment.target_duration_seconds, params.duration_seconds)) fail('segment duration must match production_parameters.duration_seconds');
for (const image of [board.board_image, board.start_frame, board.end_frame]) {
  if (!image?.image_ref) fail('storyboard board/start/end image references are required');
  if (image.aspect_ratio !== segment.video_aspect_ratio) fail('storyboard image aspect ratio must match production segment');
}

if (selection.eligibility_status !== 'ELIGIBLE' || selection.user_confirmed !== true) fail('model selection must be ELIGIBLE and user-confirmed upstream');
if (selection.duration_mode !== segment.duration_mode) fail('model selection duration_mode must match production segment');
if (selection.selected_model_id !== profile.model_id) fail('selected model ID does not match Model Profile');
if (selection.selected_profile_version !== profile.profile_version) fail('selected Model Profile version does not match');
const profileCapabilities = profile.capabilities ?? {};
const capabilities = {
  ...profileCapabilities,
  input_modalities: PROJECT_DEFAULT_CAPABILITIES.input_modalities,
  audio_capabilities: PROJECT_DEFAULT_CAPABILITIES.audio_capabilities
};

const approvedAssets = new Set(payload.approved_assets
  .filter((asset) => ['APPROVED', 'ACTIVE'].includes(asset.status))
  .map((asset) => assetKey(asset.asset_id, asset.version)));
const requiredCurrentAssets = segment.required_current_segment_assets ?? [];
const requiredAssetKeys = new Set();
for (const requiredAsset of requiredCurrentAssets) {
  const key = assetKey(requiredAsset.asset_id, requiredAsset.version);
  if (requiredAssetKeys.has(key)) fail(`duplicate required_current_segment_asset: ${key}`);
  requiredAssetKeys.add(key);
  if (!approvedAssets.has(key)) fail(`required current segment asset is unavailable: ${key}`);
  const matchingMedia = payload.media_references.find((media) => media.route === 'MODEL_INPUT'
    && media.asset_id === requiredAsset.asset_id
    && media.asset_version === requiredAsset.version
    && media.purpose === requiredAsset.required_purpose);
  if (!matchingMedia) fail(`required current segment asset is not uploaded with matching purpose: ${key}/${requiredAsset.required_purpose}`);
}
const shotMap = new Map(payload.shots.map((shot) => [shot.shot_id, shot]));
if (shotMap.size !== payload.shots.length) fail('duplicate shot_id');
if (shotMap.size !== segment.shot_ids.length) fail('shots must contain exactly the production segment shot_ids');

const cues = [];
const cueIds = new Set();
for (const shotId of segment.shot_ids) {
  const shot = shotMap.get(shotId);
  if (!shot) fail(`segment references missing shot: ${shotId}`);
  for (const field of ['basic', 'visual_description', 'camera_design', 'performance', 'sound_design', 'timeline', 'asset_refs']) {
    if (!(field in shot)) fail(`${shotId} is missing ${field}`);
  }
  for (const ref of shot.asset_refs) {
    if (!approvedAssets.has(assetKey(ref.asset_id, ref.version))) fail(`${shotId} references unavailable asset ${ref.asset_id}:${ref.version}`);
  }
  for (const cue of shot.sound_design.dialogue_cues ?? []) {
    if (cueIds.has(cue.cue_id)) fail(`duplicate dialogue cue: ${cue.cue_id}`);
    cueIds.add(cue.cue_id);
    if (!approxEqual(cue.duration_seconds, cue.end_time - cue.start_time)) fail(`${cue.cue_id} duration does not match start/end time`);
    if (cue.start_time < 0 || cue.end_time > shot.basic.duration || cue.start_time >= cue.end_time) fail(`${cue.cue_id} does not fit inside ${shotId}`);
    const speakerRef = shot.asset_refs.find((ref) => `${ref.asset_id}_v${ref.version}` === cue.speaker_character_ref && ref.asset_type === 'character');
    if (!speakerRef) fail(`${cue.cue_id} speaker is not an approved character in ${shotId}`);
    const lip = cue.lip_sync ?? {};
    if (['clear', 'partial'].includes(lip.visibility)) {
      if (lip.required !== true) fail(`${cue.cue_id} visible speech must require lip sync`);
      if (lip.mouth_visible_start > cue.start_time || lip.mouth_visible_end < cue.end_time) fail(`${cue.cue_id} mouth window does not cover dialogue`);
      if (lip.mouth_visible_end > shot.basic.duration) fail(`${cue.cue_id} mouth window exceeds shot duration`);
    }
    cues.push({...cue, shot_id: shotId});
  }
}

const mediaMap = new Map();
const submittedCounts = {image: 0, video: 0, audio: 0};
for (const media of payload.media_references) {
  if (mediaMap.has(media.media_id)) fail(`duplicate media_id: ${media.media_id}`);
  if (!['APPROVED', 'ACTIVE'].includes(media.status)) fail(`${media.media_id} is not approved`);
  if (media.purpose !== 'voice_identity' && !['CLEARED', 'USER_OWNED', 'LICENSED'].includes(media.rights_status)) fail(`${media.media_id} has no usable rights status`);
  if (media.purpose === 'music' && media.route !== 'POST_PRODUCTION') fail(`${media.media_id} music/BGM references must use POST_PRODUCTION route`);
  if (media.purpose === 'music' && media.route === 'MODEL_INPUT') fail(`${media.media_id} BGM must not be submitted to the video model`);
  mediaMap.set(media.media_id, media);
  if (media.route === 'MODEL_INPUT') submittedCounts[media.media_type] += 1;
}

for (const mediaType of ['image', 'video', 'audio']) {
  const modality = PROJECT_DEFAULT_CAPABILITIES.input_modalities[mediaType];
  if (!modality) fail(`Model Profile is missing ${mediaType} modality rules`);
  if (submittedCounts[mediaType] > 0 && !modality.supported) fail(`${mediaType} MODEL_INPUT is not supported by selected model`);
  if (submittedCounts[mediaType] > modality.max_items) fail(`${mediaType} MODEL_INPUT exceeds model max_items`);
  for (const media of payload.media_references.filter((item) => item.media_type === mediaType && item.route === 'MODEL_INPUT')) {
    if (media.duration_seconds && modality.max_duration_seconds > 0 && media.duration_seconds > modality.max_duration_seconds) fail(`${media.media_id} exceeds ${mediaType} max_duration_seconds`);
    if (media.mime_type && modality.mime_types?.length && !modality.mime_types.includes(media.mime_type)) fail(`${media.media_id} MIME type is not supported`);
  }
}

const voicesByRef = new Map();
const voicesByCharacter = new Map();
for (const voice of payload.sound_context.character_voice_assets ?? []) {
  if (voice.project_id !== payload.project_id) fail(`${voice.voice_ref} delivery belongs to another project`);
  if (!['APPROVED', 'ACTIVE'].includes(voice.voice_status)) fail(`${voice.voice_ref} is not approved`);
  if (voice.registration_status !== 'ACTIVE') fail(`${voice.voice_ref} registration is not ACTIVE`);
  if (voice.authorization_status !== 'APPROVED') fail(`${voice.voice_ref} authorization is not APPROVED`);
  if (!['GRANTED', 'NOT_REQUIRED'].includes(voice.consent_status)) fail(`${voice.voice_ref} consent is unusable`);
  if (voice.allowed_use !== 'VIDEO_GENERATION') fail(`${voice.voice_ref} is not authorized for VIDEO_GENERATION`);
  if (voice.read_only !== true) fail(`${voice.voice_ref} delivery must be read-only`);
  if (new Date(voice.authorization_valid_from) > requestedAt) fail(`${voice.voice_ref} authorization is not active yet`);
  if (voice.authorization_valid_until && new Date(voice.authorization_valid_until) < requestedAt) fail(`${voice.voice_ref} authorization has expired`);
  if (voice.voice_ref !== `${voice.voice_id}_v${voice.voice_version}`) fail(`voice_ref does not match voice_id/version: ${voice.voice_ref}`);
  if (voicesByRef.has(voice.voice_ref)) fail(`duplicate voice_ref: ${voice.voice_ref}`);
  if (voicesByCharacter.has(voice.character_asset_ref)) fail(`multiple delivered voices for ${voice.character_asset_ref}`);
  const visualMatch = /^(.+)_v([1-9][0-9]*)$/.exec(voice.character_asset_ref);
  if (!visualMatch || !approvedAssets.has(assetKey(visualMatch[1], Number(visualMatch[2])))) fail(`${voice.voice_ref} character asset is unavailable`);
  for (const audio of voice.reference_audio) {
    const media = mediaMap.get(audio.audio_id);
    if (!media || media.media_type !== 'audio' || media.purpose !== 'voice_identity') fail(`${audio.audio_id} is not a registered voice media reference`);
    if (media.uri !== audio.uri || media.voice_ref !== voice.voice_ref || media.character_asset_ref !== voice.character_asset_ref) fail(`${audio.audio_id} does not match ${voice.voice_ref}`);
    if (media.authorization_id !== voice.authorization_id) fail(`${audio.audio_id} authorization does not match ${voice.voice_ref}`);
  }
  voicesByRef.set(voice.voice_ref, voice);
  voicesByCharacter.set(voice.character_asset_ref, voice);
}

for (const cue of cues) {
    if (cue.voice_ref) {
      const voice = voicesByRef.get(cue.voice_ref);
      if (!voice) fail(`${cue.cue_id} references an undelivered voice: ${cue.voice_ref}`);
      if (voice.character_asset_ref !== cue.speaker_character_ref) fail(`${cue.cue_id} binds another character's voice`);
    }
}
for (const mediaId of payload.sound_context.audio_references ?? []) {
  if (mediaMap.get(mediaId)?.media_type !== 'audio') fail(`sound_context references unknown audio media: ${mediaId}`);
}
if (!payload.sound_context.sound_bible?.sound_bible_id) fail('sound_bible_id is required');
if (!Array.isArray(profile.prompt_format?.sections) || profile.prompt_format.sections.length === 0) fail('prompt_format.sections is required');

const usedVoiceRefs = new Set(cues.map((cue) => cue.voice_ref).filter(Boolean));
const expectedStrategy = 'MODEL_NATIVE_VOICE';
const voiceMethodNeedsAudio = true;
if (expectedStrategy === 'MODEL_NATIVE_VOICE' && voiceMethodNeedsAudio) {
  if (!capabilities.input_modalities.audio.supported) fail('native reference-audio voice conditioning requires audio input support');
  for (const voiceRef of usedVoiceRefs) {
    const voice = voicesByRef.get(voiceRef);
    if (!voice.reference_audio.some((audio) => mediaMap.get(audio.audio_id)?.route === 'MODEL_INPUT')) fail(`${voiceRef} has no submitted reference audio`);
  }
}

if (outputPath) {
  const output = readJson(outputPath, 'output');
  const outputSchema = readJson(path.join(skillRoot, 'schemas/video_generation_preparation_output.schema.json'), 'output schema');
  validateShape(output, outputSchema, outputSchema);
  if (output.project_id !== payload.project_id || output.segment_id !== segment.segment_id) fail('output project/segment identity mismatch');
  if (output.model_configuration?.model_id !== profile.model_id || output.model_configuration?.profile_version !== profile.profile_version) fail('output Model Profile mismatch');
  if (output.audio_execution_package?.strategy !== expectedStrategy) fail(`output audio strategy should be ${expectedStrategy}`);
  if (output.compatibility_report?.audio_strategy !== expectedStrategy) fail('compatibility report audio strategy mismatch');
  const audioPolicy = output.prompt_package?.sound_intent?.audio_policy;
  if (!['NATIVE_SYNC_REQUIRED', 'EXPLICIT_EXTERNAL_EXCEPTION'].includes(audioPolicy)) fail('sound_intent.audio_policy must be NATIVE_SYNC_REQUIRED or an explicit external exception');
  if (audioPolicy !== 'NATIVE_SYNC_REQUIRED') fail('project default requires NATIVE_SYNC_REQUIRED; external audio is disabled unless explicitly overridden outside this validator');
  const compiledPrompt = output.prompt_package?.main_prompt ?? '';
  const forbiddenLegacyAudio = ['无声画面', '后期加入对白', '后期加入旁白', '后期加入环境声', '后期加入拟音', '后期加入混音', 'EXPLICIT_EXTERNAL_EXCEPTION'];
  const legacyHit = forbiddenLegacyAudio.find((phrase) => compiledPrompt.includes(phrase));
  if (legacyHit) fail(`main_prompt contains forbidden legacy audio phrase: ${legacyHit}`);
  if (output.prompt_package?.sound_intent?.music?.route !== 'POST_PRODUCTION_ONLY') fail('native sync audio policy still requires music to be post-production only');
  const musicIntent = output.prompt_package?.sound_intent?.music;
  if (musicIntent && (musicIntent.route !== 'POST_PRODUCTION_ONLY' || musicIntent.submitted_to_model !== false)) fail('music intent must be POST_PRODUCTION_ONLY and not submitted to the model');
  const outputReferences = output.multimodal_references ?? [];
  const outputReferenceMap = new Map();
  const policyByPurpose = {
    first_frame: 'PRESERVE_APPROVED_COMPOSITION',
    last_frame: 'PRESERVE_APPROVED_COMPOSITION',
    character_identity: 'IDENTITY_MATERIAL_SPACE_ONLY',
    scene_identity: 'IDENTITY_MATERIAL_SPACE_ONLY',
    prop_identity: 'IDENTITY_MATERIAL_SPACE_ONLY',
    motion: 'MOTION_CAMERA_ONLY',
    camera: 'MOTION_CAMERA_ONLY',
    voice_identity: 'VOICE_IDENTITY_ONLY',
    dialogue: 'AUDIO_REFERENCE_ONLY',
    ambience: 'AUDIO_REFERENCE_ONLY',
    foley: 'AUDIO_REFERENCE_ONLY',
    rhythm: 'AUDIO_REFERENCE_ONLY',
    music: 'POST_PRODUCTION_ONLY'
  };
  for (const reference of outputReferences) {
    if (outputReferenceMap.has(reference.media_id)) fail(`duplicate output reference binding: ${reference.media_id}`);
    const sourceMedia = mediaMap.get(reference.media_id);
    if (!sourceMedia) fail(`output reference is not present in input media_references: ${reference.media_id}`);
    if (reference.media_type !== sourceMedia.media_type || reference.uri !== sourceMedia.uri || reference.purpose !== sourceMedia.purpose) fail(`${reference.media_id} output binding does not preserve source media identity`);
    if (reference.submitted_to_model !== (sourceMedia.route === 'MODEL_INPUT')) fail(`${reference.media_id} submitted_to_model does not match its input route`);
    if (reference.composition_policy !== policyByPurpose[sourceMedia.purpose]) fail(`${reference.media_id} composition policy does not match purpose ${sourceMedia.purpose}`);
    validateBindingInstruction(reference.binding_instruction, reference.media_id);
    outputReferenceMap.set(reference.media_id, reference);
  }
  for (const sourceMedia of payload.media_references) {
    if (!outputReferenceMap.has(sourceMedia.media_id)) fail(`uploaded reference is missing binding explanation: ${sourceMedia.media_id}`);
  }
  for (const requiredAsset of requiredCurrentAssets) {
    const bound = outputReferences.find((reference) => reference.submitted_to_model === true
      && reference.asset_id === requiredAsset.asset_id
      && reference.asset_version === requiredAsset.version);
    if (!bound) fail(`required current segment asset is missing from output binding: ${requiredAsset.asset_id}_v${requiredAsset.version}`);
  }
  const bindingSummary = output.prompt_package?.reference_binding_summary ?? [];
  const bindingText = output.prompt_package?.reference_binding_text;
  if (typeof bindingText !== 'string' || bindingText.trim().length === 0) fail('reference_binding_text is required');
  if (!bindingText.includes('绑定资产：')) fail('reference_binding_text must use the 绑定资产 label');
  const summaryMap = new Map(bindingSummary.map((summary) => [summary.media_id, summary]));
  if (summaryMap.size !== bindingSummary.length) fail('reference_binding_summary contains duplicate media_id');
  if (summaryMap.size !== outputReferenceMap.size) fail('reference_binding_summary must cover every multimodal reference binding');
  for (const [mediaId, reference] of outputReferenceMap) {
    const summary = summaryMap.get(mediaId);
    if (!summary) fail(`reference_binding_summary is missing ${mediaId}`);
    if (summary.binding_target_readable !== reference.binding_target_readable) fail(`${mediaId} binding_target_readable differs between reference manifest and prompt summary`);
    if (JSON.stringify(summary.binding_target) !== JSON.stringify(reference.binding_target)) fail(`${mediaId} binding_target differs between reference manifest and prompt summary`);
    if (summary.binding_instruction !== reference.binding_instruction) fail(`${mediaId} binding_instruction differs between reference manifest and prompt summary`);
    validateBindingInstruction(summary.binding_instruction, mediaId);
    if (summary.submitted_to_model !== reference.submitted_to_model || summary.composition_policy !== reference.composition_policy) fail(`${mediaId} prompt summary does not preserve binding policy`);
    if (reference.submitted_to_model && !bindingText.includes(summary.binding_target_readable)) fail(`${mediaId} binding target is missing from reference_binding_text: ${summary.binding_target_readable}`);
    if (!reference.submitted_to_model && bindingText.includes(summary.binding_target_readable)) fail(`${mediaId} unsubmitted binding target must not appear in reference_binding_text: ${summary.binding_target_readable}`);
    if (reference.submitted_to_model && !bindingText.includes(summary.binding_instruction)) fail(`${mediaId} binding instruction is missing from reference_binding_text`);
  }
  const visibleReferenceCount = outputReferences.filter((reference) => reference.submitted_to_model).length;
  const visibleBindingCount = (bindingText.match(/(?:^|\n)\s*-\s*绑定资产：/g) ?? []).length;
  if (visibleBindingCount !== visibleReferenceCount) fail(`reference_binding_text must contain exactly one binding line per submitted reference (${visibleReferenceCount} expected, ${visibleBindingCount} found)`);
  if (expectedStrategy !== 'MODEL_NATIVE_VOICE') fail('project default audio strategy must be MODEL_NATIVE_VOICE');

  const artifactManifest = output.artifact_manifest;
  if (!Array.isArray(artifactManifest) || artifactManifest.length === 0) fail('artifact_manifest must contain at least one deliverable');
  const segmentNumberMatch = /([0-9]+)$/.exec(segment.segment_id);
  const expectedSegmentPrefix = segmentNumberMatch ? `第${String(Number(segmentNumberMatch[1])).padStart(2, '0')}段_` : null;
  const artifactIds = new Set();
  const artifactFileNames = new Set();
  const artifactSequenceNumbers = new Set();
  for (const artifact of artifactManifest) {
    if (artifactIds.has(artifact.artifact_id)) fail(`duplicate artifact_id: ${artifact.artifact_id}`);
    if (artifactFileNames.has(artifact.file_name)) fail(`duplicate artifact file_name: ${artifact.file_name}`);
    if (artifactSequenceNumbers.has(artifact.sequence_no)) fail(`duplicate artifact sequence_no: ${artifact.sequence_no}`);
    artifactIds.add(artifact.artifact_id);
    artifactFileNames.add(artifact.file_name);
    artifactSequenceNumbers.add(artifact.sequence_no);
    const fileMatch = /^(第[0-9]{2}段_)([\u4e00-\u9fff].+)\.(json|txt|yaml|zip)$/.exec(artifact.file_name);
    if (!fileMatch) fail(`${artifact.file_name} must use Chinese numbered naming: 第01段_中文资料名.扩展名`);
    if (expectedSegmentPrefix && fileMatch[1] !== expectedSegmentPrefix) fail(`${artifact.file_name} does not match segment ${segment.segment_id}`);
    if (artifact.display_name !== artifact.file_name.slice(0, -(artifact.format.length + 1))) fail(`${artifact.artifact_id} display_name must match file_name without extension`);
    if (fileMatch[3] !== artifact.format) fail(`${artifact.artifact_id} format does not match file extension`);
    if (artifact.machine_ref !== output.generation_package_id) fail(`${artifact.artifact_id} machine_ref must match generation_package_id`);
  }

  const outputCues = new Map((output.audio_execution_package?.dialogue_cues ?? []).map((cue) => [cue.cue_id, cue]));
  if (outputCues.size !== cues.length) fail('output must preserve every dialogue cue exactly once');
  for (const cue of cues) {
    const compiled = outputCues.get(cue.cue_id);
    if (!compiled) fail(`output is missing ${cue.cue_id}`);
    for (const field of ['shot_id', 'speaker_character_ref', 'voice_ref', 'text', 'start_time', 'end_time', 'emotion']) {
      const expected = field === 'shot_id' ? cue.shot_id : cue[field];
      if (compiled[field] !== expected) fail(`${cue.cue_id} changed immutable field ${field}`);
    }
    if (compiled.lip_sync_required !== cue.lip_sync.required) fail(`${cue.cue_id} changed lip-sync requirement`);
  }

  const bindings = new Map((output.character_voice_bindings ?? []).map((binding) => [binding.voice_ref, binding]));
  if (bindings.size !== usedVoiceRefs.size) fail('output must contain one binding per used voice_ref');
  const expectedBindingStatus = expectedStrategy === 'MODEL_NATIVE_VOICE'
    ? 'BOUND_TO_MODEL'
    : expectedStrategy === 'PREGENERATED_DIALOGUE_DRIVE'
      ? 'PREGEN_DIALOGUE_REQUIRED'
      : 'ROUTED_TO_EXTERNAL_AUDIO';
  for (const voiceRef of usedVoiceRefs) {
    const sourceVoice = voicesByRef.get(voiceRef);
    const binding = bindings.get(voiceRef);
    if (!binding) fail(`output is missing voice binding ${voiceRef}`);
    if (binding.character_asset_ref !== sourceVoice.character_asset_ref || binding.voice_version !== sourceVoice.voice_version) fail(`${voiceRef} binding changed voice identity`);
    if (binding.delivery_id !== sourceVoice.delivery_id || binding.authorization_id !== sourceVoice.authorization_id) fail(`${voiceRef} binding lost delivery authorization trace`);
    if (binding.status !== expectedBindingStatus) fail(`${voiceRef} binding status does not match ${expectedStrategy}`);
    const expectedCueIds = cues.filter((cue) => cue.voice_ref === voiceRef).map((cue) => cue.cue_id).sort();
    if (JSON.stringify([...binding.cue_ids].sort()) !== JSON.stringify(expectedCueIds)) fail(`${voiceRef} binding cue_ids mismatch`);
  }

  const steps = output.audio_execution_package?.steps ?? [];
  const stepIds = new Set();
  let previousOrder = 0;
  for (const step of steps) {
    if (step.order <= previousOrder) fail('audio execution steps must have increasing order');
    previousOrder = step.order;
    for (const dependency of step.depends_on ?? []) if (!stepIds.has(dependency)) fail(`${step.step_id} depends on a missing or later step`);
    if (stepIds.has(step.step_id)) fail(`duplicate execution step: ${step.step_id}`);
    stepIds.add(step.step_id);
  }
}

if (fs.existsSync(casesPath)) {
  const cases = readJson(casesPath, 'audio routing cases').cases ?? [];
  if (cases.length < 4) fail('audio routing fixture must cover at least four strategies');
  for (const testCase of cases) {
    const actual = deriveAudioStrategy(testCase.audio_capabilities, testCase.speaker_count, testCase.dialogue_cue_count);
    if (actual !== testCase.expected_strategy) fail(`routing case '${testCase.name}' expected ${testCase.expected_strategy}, got ${actual}`);
  }
  console.log(`PASS: ${cases.length} audio routing cases`);
}

console.log(`PASS: ${payload.project_id}/${segment.segment_id}, ${payload.shots.length} shots, ${cues.length} dialogue cues, ${usedVoiceRefs.size} voices, strategy=${expectedStrategy}, model inputs image=${submittedCounts.image} video=${submittedCounts.video} audio=${submittedCounts.audio}`);

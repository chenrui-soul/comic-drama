import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = fs.readdirSync(path.join(root, 'model_profiles')).filter((name) => name.endsWith('.yaml'));
let failed = false;

for (const name of files) {
  const text = fs.readFileSync(path.join(root, 'model_profiles', name), 'utf8');
  const requiredKeys = [
    'production_status:',
    'input_modalities:',
    'audio_capabilities:',
    'audio_generation:',
    'voice_conditioning:',
    'dialogue_audio_drive:',
    'lip_sync:'
  ];
  const missing = requiredKeys.filter((key) => !text.includes(key));
  if (missing.length) {
    console.error(`FAIL: ${name} missing ${missing.join(', ')}`);
    failed = true;
  } else {
    console.log(`PASS: ${name} declares v1.2 audio capabilities`);
  }
}

if (failed) process.exit(1);

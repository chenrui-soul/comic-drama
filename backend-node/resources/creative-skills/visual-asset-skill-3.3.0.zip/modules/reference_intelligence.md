# Reference Intelligence

## Purpose
管理参考素材与生产资产关系。

## Input
Reference assets plus an approved Art Direction package.

## Process
Reference Analysis
Contract Extraction
Production Constraint

## Output
Style Contract and per-asset Design Contracts, each with a stable ID and source version. The extracted contract must be traceable to the Art Direction ID and version.

## Validation
禁止直接将参考图作为生产资产；必须记录来源、用途和提取出的约束。

## Failure Handling
解析失败或 Style Contract 缺失时停止生产，并返回可定位的 issue code。

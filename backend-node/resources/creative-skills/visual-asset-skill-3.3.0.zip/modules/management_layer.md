# Management Layer

## Purpose
负责资产生命周期管理。

## Input
Registered Asset

## Process
Registration → Authorization Check → Idempotency Check → Version Management → Dependency Management → Approval Transition → Impact Analysis → Delivery Audit → Retrieval

## Output
Active Asset Record

## Validation
检查 `asset_id` 稳定性、版本单调递增、幂等键、依赖存在性和状态迁移是否合法。声音资产还必须检查注册状态、授权范围与有效期、版本血缘和交付记录；未注册或未授权的声音不能进入 `ACTIVE`。

## Failure Handling
失败进入 `REVISION`，不改变当前 `ACTIVE` 指针；可重试错误保留同一请求上下文，不可重试错误返回恢复动作。授权撤销或过期立即阻止新的声音交付，但不得覆盖或删除历史交付记录。

# Production Layer

## Purpose
负责视觉资产生产。

## Input
Style Contract, Design Contract, Production Spec and an asset request.

## Process
Contract解析 → Scope确认 → Style Lock → View Packaging → Asset Generation → AI Validation → Human Review

## Output
符合 `schemas/asset_object_schema.json` 的版本化 Asset Object。

## Validation
检查必需视图、格式、身份锚点、状态连续性、风格契约和生产可用性。完整场景五视必须交付为两张图：独立 `top90` 与包含正、反、左、右的 2x2 `orthographic_4view`；两张图必须保持方向轴、比例、结构和地标一致。

## Failure Handling
进入 `REVISION`，保留失败结果和 issue 列表；顶俯视图失败只重做 `top90` 文件。正、反、左、右任一面失败时，只重做对应面并重新合成 `orthographic_4view` 文件，已通过的顶俯视图不重做。跨文件空间不一致时才同时重做两张图。不得把失败结果注册为 `ACTIVE`。

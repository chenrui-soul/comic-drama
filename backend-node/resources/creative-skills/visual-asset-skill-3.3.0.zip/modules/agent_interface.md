# Agent Interface

## Purpose
提供下游Agent资产访问。

## Input
符合 `schemas/agent_request_schema.json` 的只读 Agent Request。

## Process
验证请求 → 幂等键查询 → 执行指定 operation → 返回结果与恢复信息

支持的 operation：`PROPOSE_SCOPE`、`GENERATE`、`REVISE`、`VALIDATE`、`RETRIEVE`。

## Output
符合 `schemas/agent_response_schema.json` 的 Asset Response；返回资产时必须包含完整 `asset_ref`。声音交付还必须返回固定 `voice_ref`、注册、授权和交付记录。

## Validation
检查权限、请求类型、资产类型、版本、幂等键和可下游使用状态（`APPROVED` 或 `ACTIVE`）。`GENERATE` 必须有已确认的 scope；`REVISE` 必须提供目标资产和修改范围。声音 `RETRIEVE` 还必须校验 consumer、allowed use、注册为 `ACTIVE`、授权为 `APPROVED` 且未过期或撤销。

## Failure Handling
返回 `NOT_FOUND`、`FORBIDDEN`、`INVALID_REQUEST` 或执行错误对象，不降级返回过期版本；可重试错误必须保留原 `request_id` 和 `idempotency_key`。声音授权不满足时返回 `FORBIDDEN`，不得返回音频 URI，也不得自动换用其他声音版本。

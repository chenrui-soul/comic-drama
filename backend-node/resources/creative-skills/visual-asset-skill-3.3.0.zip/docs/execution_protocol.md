# Execution Protocol

## Master Agent call

Every invocation carries `execution_id`, `request_id` and `idempotency_key`. The same idempotency key must return the existing result instead of creating a duplicate asset version.

Supported operations:

- `PROPOSE_SCOPE`: analyze requests and return a scope proposal; never generate files.
- `GENERATE`: generate only after scope confirmation is `CONFIRMED`.
- `REVISE`: regenerate one asset, view or state variant and create a new version.
- `VALIDATE`: rerun checks without changing the active version.
- `RETRIEVE`: return only approved or active read-only assets.

## Result handling

`COMPLETED` means the requested operation finished. `WAITING_CONFIRMATION` means scope must be confirmed. `WAITING_APPROVAL` means files exist but a human has not approved them. `PARTIAL_SUCCESS` means some asset requests succeeded and others have request-scoped errors. `FAILED` means no safe result was produced.

## Recovery

Retry only errors marked `retryable=true`. A retry keeps the same request and idempotency key, increments the execution attempt, and does not replace an existing `ACTIVE` asset. Non-retryable errors return a suggested revision or upstream review action.

The caller may safely repeat a completed request with the same idempotency key. The module must return the stored result and must not create another asset version.

## Local revision

`REVISE` must identify `target_asset_ref` and a scope of `ASSET`, `VIEW`, or `STATE_VARIANT`. The result records `supersedes`, `change_reason`, generated views, omitted views and an impact analysis. Unaffected assets remain untouched.

For a full-view scene, `top90` is an independent physical revision target. A defect in `front`, `back`, `left`, or `right` revises that logical panel and rebuilds only the `orthographic_4view` file. Rebuild both scene files only when the shared direction, scale, geometry or landmark lock fails.

## Trace record

The output trace records source Art Direction and Contract versions, timestamps, Prompt Hashes and all local state transitions. This is the audit record for the asset operation.

## Voice asset execution

A voice asset may enter `APPROVED` only after its audio and identity checks pass. It may enter `ACTIVE` only when its registration is `ACTIVE` and its authorization is `APPROVED`; human recordings additionally require `consent_status=GRANTED`.

`REVISE` creates a new immutable `voice_ref` and records `supersedes` and `change_reason`. It must not modify an existing delivery record or silently rebind a character to another voice version.

`RETRIEVE` for a voice asset requires an allowed use and consumer. Before returning audio references, verify registration, authorization status, consent, project and character scope, territory, validity window and requested use. A successful handoff writes one `voice_delivery_schema.json` record. Authorization revocation or expiry blocks new delivery but preserves historical delivery records.

# Asset Scope Policy

Visual Asset first decides what needs to be produced, then produces only the confirmed scope. Asset type alone does not determine view count.

## Default policy

| Type | S/A | B | C/X | G |
|---|---|---|---|---|
| Character | `full_views` | `reduced_views` | `single_reference` or `none` | `group_archetype` |
| Prop | `full_views` | `reduced_views` | `single_reference` or `none` | not applicable |
| Scene | `full_views` for reusable locations | policy-driven | `single_reference` | not applicable |

Scene `full_views` always uses `scene_view_packaging=split_top_plus_orthographic_4view`: one standalone `top90` image and one labeled 2x2 `front/back/left/right` sheet. This packaging choice does not reduce the five logical views.

## User confirmation

When the request does not explicitly define a level or policy, return a batch scope proposal. The proposal must include the reason, estimated output, omitted views, and the condition that would justify an upgrade. Wait for `scope_confirmation.status=CONFIRMED` before generating.

## Upgrade triggers

Upgrade a reduced asset to full views when the asset has multiple camera angles, close-ups, physical interaction, repeated continuity requirements, transformation states, or becomes story-critical.

## Group characters

G-level characters use a group sheet plus a small set of archetypes with shared wardrobe, silhouette and color rules. A named or recurring member can be promoted to B/A and receive an independent asset version without regenerating the whole group.

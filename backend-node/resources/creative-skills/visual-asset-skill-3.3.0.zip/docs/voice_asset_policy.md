# Character Voice Asset Policy

## Purpose

Store a stable character voice identity for later TTS or video generation systems that accept a voice reference. This module registers and validates voice references; it does not synthesize speech.

## Duration

Use one clean neutral anchor of 20 seconds as the default. Ten seconds is the minimum for a basic identity reference. Fifteen to thirty seconds is the recommended production range. Do not make the anchor longer than 60 seconds unless the downstream model explicitly requires it.

Optional emotion samples should be separate files of 8–12 seconds each. Recommended examples are calm, angry, grieving, whispering or laughing, selected according to the character's actual performance needs.

## Recording requirements

- one speaker and one language per file;
- dry voice, no music, no room reverb and no competing noise;
- natural delivery at the character's normal pitch and speaking rate;
- 2–3 complete sentences for the neutral anchor;
- record the script and pronunciation notes in metadata when proper nouns matter.

## Level policy

| Level | Default voice output |
|---|---|
| S/A | neutral anchor, voice profile, optional emotion samples |
| B | user-selectable neutral anchor or voice profile only |
| G | group voice rules and a limited set of voice archetypes |
| C/X | no independent voice asset by default |

## Versioning

Visual and voice versions are independent. `P001_v2` may continue using `VOICE-P001_v1`; changing the voice creates a new `voice_version` and records `supersedes` without invalidating the visual asset.

Each voice version is immutable after approval. A replacement increments `voice_version`, creates a new `voice_ref`, and records `supersedes`, `change_reason`, `source_request_id` and `execution_id`. Existing delivery records continue to point to the exact version originally delivered.

## Registration

Every voice asset must have one registration record before it can become `ACTIVE`. The record binds `voice_id`, `voice_ref`, `voice_version`, project, character, source type, registrant, timestamp and content checksum. Registration status must be `ACTIVE` before handoff. Re-registering the same idempotent request must return the stored registration rather than create a duplicate.

## Authorization

Authorization is version-pinned and project-scoped. It records the rights holder, consent state, permitted uses, territory, validity period, proof URI and restrictions.

- Human recordings require `consent_status=GRANTED`.
- Licensed or synthetic sources may use `NOT_REQUIRED` only when the proof URI establishes that no additional performer consent is required.
- Authorization must be `APPROVED` before the voice asset becomes `ACTIVE` or is delivered.
- `PENDING`, `DENIED`, `REVOKED` and `EXPIRED` authorization blocks delivery.
- Revocation or expiry blocks new deliveries immediately; historical delivery records remain immutable for audit.

## Downstream handoff

The handoff exposes `voice_ref`, version-pinned reference audio URIs, voice profile and voice locks as read-only data. Every handoff creates a delivery record containing the registration, authorization, consumer, allowed use and timestamp. The requested use must be present in `allowed_uses` and must fall within authorization scope and validity. A downstream executor decides whether its selected TTS or video model supports reference audio and reports compatibility separately.

The Visual Asset module registers and hands off voice identity. It does not grant rights, infer consent, synthesize speech, edit audio or guarantee downstream model compatibility.

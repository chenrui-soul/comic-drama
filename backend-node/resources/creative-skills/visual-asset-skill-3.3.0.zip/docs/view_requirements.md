# View Requirements

The required views are production defaults. A request may add views, but it may not omit the identity views for the asset type.

| Asset type | Required views |
|---|---|
| character | `closeup`, `front`, `side`, `back` |
| scene | logical views: `top90`, `front`, `back`, `left`, `right`; physical files: `top90` + `orthographic_4view` |
| prop | `front`, `side`, `top`, `detail` |
| video_style | `color_card`, `style_reference` |

Character and prop views use a clean white background. Character views show a complete body where applicable. Scene views preserve spatial layout and do not require a white background. Prop views preserve proportions and material details.

## Scene five-view packaging

For a scene using `full_views`, keep five logical views but deliver exactly two base-view files:

1. `<中文场景名>场景<编号>_顶俯视图.png`: one standalone 90-degree top view.
2. `<中文场景名>场景<编号>_正反左右四视图.png`: one labeled 2x2 sheet in fixed panel order `front`, `back`, `left`, `right`.

Do not place all five views in one sheet and do not create an empty sixth panel. Both files belong to the same `scene_asset_ref` and version. `required_views` records the five logical views; `files` records the two physical outputs.

The Chinese base name and number must be identical across both files. Keep machine `file_id` and `asset_ref` separate from the human-facing `file_name`; see `docs/naming_convention.md`.

Declare a stable `front_axis` before generation. If the Design Contract does not define the front direction, request user confirmation. The top view and four-view sheet must share orientation, scale, geometry, entrances, doors, windows, fixed furniture and landmarks. Outdoor or open scenes still use the declared front axis as their directional reference.

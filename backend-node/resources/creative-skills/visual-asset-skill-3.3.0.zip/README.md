# 资产 Skill v3.3.0

与 AI 漫剧导演 Agent 框架对齐的视觉资产生产模块。

## 负责范围

角色、场景、道具和视频风格资产的生产、校验、审批、版本管理、依赖管理和下游只读访问；角色声音资产包括注册、授权证据、独立版本和交付审计。

## 不负责范围

剧本分析、导演分镜、故事板构图、视频模型选择和视频生成执行。

## 入口与契约

- Codex 原生入口：`SKILL.md`
- 输入：`schemas/input_schema.json`
- 输出：`schemas/output_schema.json`
- 资产对象：`schemas/asset_object_schema.json`
- 上游接口：`contracts/art_direction_input.yaml`
- 下游接口：`contracts/downstream_handoff.yaml`
- 声音交付接口：`contracts/voice_asset_handoff.yaml`

## 生产原则

1. 只使用已批准的 Art Direction。
2. 一个实体一个稳定 `asset_id`，修改只递增 `version`。
3. 资产文件、固定 Prompt、状态和验证结果必须绑定到同一版本。
4. 下游只引用 `asset_ref`，不复制或改写资产身份。
5. 单资产问题局部重做；系统性风格漂移才回退 Art Direction。
6. 完整场景五视按两张图交付：独立顶俯视图加正反左右四宫格图。
7. 用户可见资产名和文件名使用中文名称加项目内编号；机器 ID 保持 ASCII。

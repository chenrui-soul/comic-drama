---
name: "visual-asset-skill"
description: "Create, validate, register, and manage production-ready character, scene, prop, and character voice assets with tiered generation, rights-aware voice delivery, approval, versioning, and traceability."
metadata:
  display_name: "资产"
  version: "3.3.0"
  contract_version: "1.3"
  entrypoint: "SKILL.md"
---

# 资产 Skill v3.3.0

AI漫剧视觉资产生产与管理核心 Skill。它把已批准的美术方向固化为可复用、可追踪、可被下游 Agent 精确引用的资产包。

## Boundary

负责：
- 编译 Art Direction 的 Style Contract
- 角色、场景、道具资产生产
- 为角色建立声音身份、参考音频、注册、授权和交付记录
- 多视图与状态变体管理
- AI 检查、人工审批和发布
- 资产注册、版本、依赖和检索
- 向 Storyboard / Video Agent 提供只读资产引用

不负责：
- 剧本分析
- 分镜生成
- 摄影设计
- 视频生成
- TTS 配音合成
- 音频剪辑、口型同步和 BGM 生成

## Execution Contract

输入必须符合 `schemas/input_schema.json`，且 `art_direction.status` 必须为 `APPROVED` 或 `ACTIVE`。每个资产请求必须声明 `asset_type`、`asset_level`、来源实体和 `production_policy`。

生成前先输出资产范围建议；`scope_confirmation.status` 为 `PENDING` 时只能等待用户确认，不得生成资产。只有 `CONFIRMED` 才能进入生产。

每次调用必须携带 `execution_id`、`request_id` 和 `idempotency_key`。调用语义、恢复和局部重做规则见 `docs/execution_protocol.md`。

输出必须符合 `schemas/output_schema.json`。输出中的资产使用稳定 `asset_id` 加整数 `version` 标识；版本只能递增，历史版本不可覆盖或物理删除。失败必须写入 `errors`，并返回 `retryable` 与建议动作。

输出始终包含 `voice_assets`、`voice_registrations`、`voice_authorizations` 和 `voice_deliveries` 数组；没有声音资产时返回空数组。

## Scope and Lifecycle

资产等级：

| Level | Meaning | Default |
|---|---|---|
| `S` | 核心主资产 | 完整视图 |
| `A` | 重要高频资产 | 完整视图 |
| `B` | 次要但有明确作用 | 精简视图，可升级 |
| `C` | 普通功能性资产 | 单图或不单独生成 |
| `G` | 群像/批量资产 | 群像图或原型资产 |
| `X` | 仅提及/无需独立资产 | 不生成 |

```text
SCOPE_REVIEW →
ASSET_GENERATING → AI_CHECK → HUMAN_REVIEW → APPROVED → ACTIVE
                                      └──────→ REVISION
```

只有 `APPROVED` 或 `ACTIVE` 资产可以交付下游；`ACTIVE` 是当前默认引用版本。B 级及以下资产不默认生成完整多视图，G 级角色使用群像/原型模式。

完整场景资产保留 `top90`、`front`、`back`、`left`、`right` 五个逻辑视角，但固定交付两张图：一张独立顶俯视图和一张按正、反、左、右排列并标注方向的 2x2 四宫格。两张图必须属于同一 `scene_asset_ref` 和版本，并遵守 `schemas/scene_view_package_schema.json`。

用户可见资产名和交付文件名默认使用中文名称加编号；场景文件固定为 `<中文场景名>场景<编号>_顶俯视图.png` 与 `<中文场景名>场景<编号>_正反左右四视图.png`。命名细则见 `docs/naming_convention.md`。内部 `asset_id`、`asset_ref`、`file_id` 保持 ASCII，不作为用户可见名称。

角色声音资产规则：S/A 级角色默认建立声音资产；B 级角色可由用户选择；G 级角色输出群像声音原型；C/X 级角色不强制建立独立声音资产。默认声音锚点为 20 秒，允许 10–60 秒；推荐使用 15–30 秒干净中性语音。

声音资产与视觉资产独立版本管理：`P001_v2` 的视觉修改不自动生成 `VOICE-P001_v2`，声音修改也不使视觉资产失效。

声音资产必须满足 `schemas/voice_asset_schema.json`。未注册或未获得有效授权的声音不得进入 `ACTIVE`，也不得交付；授权撤销或过期后必须停止新的交付。每次声音交付必须固定 `voice_ref`，记录 consumer、允许用途和时间，并遵守 `contracts/voice_asset_handoff.yaml`。Visual Asset 只登记授权证据，不自行授予或推断声音使用权。

资产包审批和单资产审批同时存在：资产包可以是 `PARTIAL_SUCCESS`，单个资产通过后即可作为独立只读引用交付；未通过的资产不得阻塞无关资产。

每次生成、校验、审批、版本替换都必须写入输出 `trace`，包括来源版本、Prompt Hash 和状态迁移。

## Modules

| Module | Responsibility |
|---|---|
| Reference Intelligence | 把参考素材转成 Style / Design Contract，不把参考图直接当生产资产 |
| Production Layer | 按 Contract 生产并验证资产 |
| Management Layer | 注册、版本、依赖、状态和归档 |
| Agent Interface | 按权限和版本返回只读资产数据 |

## Handoff

下游只接收 `contracts/downstream_handoff.yaml` 定义的 `asset_ref`、文件、固定 Prompt、状态和校验结果；声音资产还必须满足 `contracts/voice_asset_handoff.yaml`。禁止下游自行重建人物、场景、道具或声音身份。

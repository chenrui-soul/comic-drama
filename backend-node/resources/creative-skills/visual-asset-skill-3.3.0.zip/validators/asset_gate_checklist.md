# Asset Gate Checklist

## Input Gate

- [ ] Art Direction package has status `APPROVED` or `ACTIVE`.
- [ ] `style_contract_id` resolves to one immutable Style Contract.
- [ ] Every request has a source entity and required views.
- [ ] Every request has an asset level and production policy.
- [ ] Every user-facing asset has a Chinese `display_name` with a stable project-local number.
- [ ] Scope proposal has been confirmed by the user before generation.
- [ ] Reference images are labeled as references, not registered assets.

## Asset Gate

- [ ] Required views exist for the requested asset type.
- [ ] Required views match the confirmed production policy, not an unapproved default.
- [ ] Character and prop files use a clean white background; scene files follow the scene production spec.
- [ ] G-level character requests use group/archetype output unless individual identity is explicitly required.
- [ ] B-level prop requests do not contain unnecessary views unless an upgrade reason is recorded.
- [ ] Full-view scenes preserve five logical views but contain exactly two base-view files: standalone `top90` and labeled 2x2 `orthographic_4view`.
- [ ] Scene files use the same Chinese base name and number: `<名称>场景<编号>_顶俯视图.png` and `<名称>场景<编号>_正反左右四视图.png`.
- [ ] The four-view scene sheet uses fixed panel order `front`, `back`, `left`, `right` and has no empty or extra panel.
- [ ] Scene `front_axis` and orientation marker are declared; both files match in scale, geometry, entrances, fixed furniture and landmarks.
- [ ] Both scene files share one `scene_asset_ref` and version; no five-view single-sheet output is accepted.

## Voice Asset Gate

- [ ] S/A character voice assets include a neutral anchor sample by default.
- [ ] B character voice production is explicitly confirmed by the user.
- [ ] G character requests use shared voice rules or voice archetypes, not one voice per person by default.
- [ ] Neutral anchor duration is 10–60 seconds, with 15–30 seconds recommended and 20 seconds as the default.
- [ ] Reference audio is clean, dry, free of music and background noise.
- [ ] `voice_ref` and `voice_version` are independently versioned from the visual asset.
- [ ] Voice asset is approved before downstream TTS or video voice binding.
- [ ] Every voice version has one matching registration record; registration is `ACTIVE` before handoff.
- [ ] Authorization is version-pinned, project-scoped, supported by a proof URI and `APPROVED`.
- [ ] Human recordings have `consent_status=GRANTED`; `NOT_REQUIRED` is backed by licensing or synthetic-source proof.
- [ ] Requested use is listed in `allowed_uses` and is within territory and validity dates.
- [ ] `PENDING`, `DENIED`, `REVOKED` or `EXPIRED` authorization blocks new delivery.
- [ ] A changed voice increments `voice_version` and records `supersedes`, `change_reason`, request and execution IDs.
- [ ] Every file has a URI, MIME type, view type and checksum.
- [ ] Identity anchor and forbidden changes are recorded.
- [ ] Prompt stack contains global, style, asset, view, state and negative layers.
- [ ] Dependencies resolve to existing asset references.

## Approval Gate

- [ ] AI checks include format, identity, continuity, style and production readiness.
- [ ] All `ERROR` issues are resolved before human review.
- [ ] A human reviewer and timestamp are recorded.
- [ ] Only `APPROVED` assets can become `ACTIVE`.
- [ ] A revision creates a new version and leaves the active version unchanged.

## Handoff Gate

- [ ] Downstream payload contains immutable `asset_ref` values.
- [ ] No `DRAFT`, `REVISION`, `DEPRECATED` or `ARCHIVED` asset is handed off.
- [ ] The handoff is marked read-only.
- [ ] Every voice handoff records the exact voice version, registration, authorization, consumer, allowed use and delivery timestamp.
- [ ] Voice identity, version and reference audio are immutable to the consumer.

# Visual Asset Output Format Spec

## Identity and file rules

Every file belongs to exactly one `asset_ref` and one `view_type`. Keep file URI, MIME type and checksum in the Asset Object. A failed or unapproved file must never be exposed through the downstream handoff.

Every user-facing asset has a Chinese `display_name` with a project-local number. Every delivered file has a Chinese `file_name` using that same base name and number. Machine identifiers remain in `asset_id`, `asset_ref` and `file_id`.

## Character Voice Asset

声音资产用于后续 TTS 或支持声音参考的视频模型固定角色声线。Visual Asset 只登记声音身份和参考音频，不执行配音合成。

- 标准中性声音锚点：20 秒
- 最低可用时长：10 秒
- 推荐时长：15–30 秒
- 单个参考音频上限：60 秒
- 必须为干声：无 BGM、无混响、无明显环境噪声
- 建议包含 2–3 句自然台词，覆盖角色常用音区
- 情绪样本为可选，每条建议 8–12 秒

声音文件字段至少包含：`voice_ref`、`character_asset_ref`、`sample_type`、`uri`、`duration_seconds`、`mime_type`、`checksum`。

## Character Asset

白底四视图：
- Face Close-up
- Front
- Side
- Back

禁止海报、氛围图。


Required view names are `closeup`, `front`, `side`, `back`.

S/A 级角色默认生成四视图；B 级按镜头使用情况选择母版、特写或侧视；G 级输出群像图和有限数量的原型角色，不为每名群像成员默认生成四视图；C/X 级不强制完整角色资产。

## Scene Asset

场景仍覆盖五个逻辑视角：`top90`、`front`、`back`、`left`、`right`，但固定拆成两张物理文件：

1. `SCN001_v1_top90.png`：单独的 90 度顶俯视图。
2. `SCN001_v1_orthographic_4view.png`：正、反、左、右四宫格，采用 2x2 排版；第一行 `front`、`back`，第二行 `left`、`right`。

四宫格必须显示方向标签，不得把五视图塞入同一张图，也不得留下空白宫格。两张图使用同一 `scene_asset_ref`、版本、方向轴、比例、场景结构和固定地标。场景不要求白底。

`generated_views` 记录五个逻辑视角，`files` 只登记 `top90` 与 `orthographic_4view` 两个物理交付文件。包装元数据必须符合 `schemas/scene_view_package_schema.json`。


## Prop Asset

多视图：
- Front
- Side
- Top
- Detail

白底输出。
保持比例、材质一致。

S/A 级道具默认四视图；B 级默认正面主视图加细节图，只有在多角度、互动或连续性要求下才升级为四视图；C/X 级不强制四视图。

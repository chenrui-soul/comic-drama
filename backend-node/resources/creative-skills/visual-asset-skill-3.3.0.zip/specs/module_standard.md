# Skill Module Standard

所有模块必须包含：

1. Purpose
2. Input
3. Process
4. Output
5. Validation
6. Failure Handling
